console.log("hi here");



class Player {
    constructor(x, y, r) {
        this.x = x;
        this.y = y;
        this.r = r;
    }

    drawPlayer() {
        fill('red')
        circle(this.x, this.y, this.r*2)
        
    }

    movePlayer() {

        if(keyIsDown(RIGHT_ARROW)) {
            this.x += 10;
            if(this.x + this.r > 400) {
                this.x -= 10;
            }
        }

        if(keyIsDown(LEFT_ARROW)) {
            this.x -= 10;
            if(this.x - this.r < 0) {
                this.x += 10;
            }
        }

        if(keyIsDown(UP_ARROW)) {
            this.y -= 10;
            if(this.y - this.r < 0) {
                this.y += 10;
            }
        }

        if(keyIsDown(DOWN_ARROW)) {
            this.y += 10;
            if(this.y + this.r > 400) {
                this.y -= 10;
            }
    
        }
    }


}

let player = new Player(20,20,17)