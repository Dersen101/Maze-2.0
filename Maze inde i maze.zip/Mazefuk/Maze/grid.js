console.log("hi")

let cols, rows;
let w = 40; //width and height of one cell
let grid = [];

let current;

let stack = []; //empty array

function setup() {
    createCanvas(400,400);
    cols = floor(width/w);
    rows = floor(height/w); //hvad er en floor funktion?
    frameRate(60)

    for(let j = 0; j < rows; j++) { //for every row, go through every column, first row - create every cell so on so forth...
        for (let i = 0; i < cols; i++ ) {
            let cell = new Cell(i,j);
            grid.push(cell); //make the cells, and put it in the array
        }
    }

    current = grid[0]; //start the current cell at 0, top left corner - kan ændres til behov

}

function draw() {
    background(51);
    
    for(let i = 0; i < grid.length; i++ ) {
        grid[i].show();
    }
    
    current.visited = true; //skal tegne noget
    current.highlight();
    //step 1
    let next = current.checkNeighbors(); //check neighbor, find a random unvisited one and return it
    if (next) {
        next.visited = true;
        //step 2
        stack.push(current);
        //step 3
        removeWalls(current,next);
        
        //step 4
        current = next;
    } 
    else if(stack.length > 0) {
        current = stack.pop();
        
    }

    player.drawPlayer(); //skal synliggøres efter algoritmen er done...
    player.movePlayer();
    

}

function index(i, j) {
    if (i < 0 || j< 0|| i> cols-1|| j> rows-1) { //invalid index values i has to be between 0 and cols-1, so with j
        return -1;
    }
    
    return i+j*cols;
}

function Cell(i,j) {
    this.i = i; //column number
    this.j =j; // row number
    this.walls= [true, true, true, true] // every wall is there, top right bottom left
    this.visited = false; //each cell should not be visited - at first
    this.checkNeighbors = function() {
        let neighbors = [];

        
        let top = grid[index(i, j-1)];
        let right = grid[index(i+1, j)];
        let bottom = grid[index(i, j+1)];
        let left = grid[index(i-1, j)];

        if (top && !top.visited) { // alt her er duplikeret, der kan evt. findes en mere optimeret måde at skrive det her på
                            // men sådan er det, 
            neighbors.push(top);
        }

        if (right && !right.visited) { // as long as right is real, and has not been visited, then it can go into the array
            neighbors.push(right);
        }

        if (bottom && !bottom.visited) {
            neighbors.push(bottom);
        }

        if (left && !left.visited) {
            neighbors.push(left);
        }
        
        if(neighbors.length > 0 ) { // in the current cell, looking at all its neighbors, finding any that hasnt been visted
                                    // and then we are going to visit the unvisited neighbor/cell

            let r = floor(random(0, neighbors.length));
            return neighbors[r];

        } else {
            return undefined;
        }
    }

    this.highlight = function() {
        let x = this.i*w; 
        let y = this.j*w;
        noStroke();
        fill(0,0,255,100);
        rect(x,y,w,w);
    }

    this.show = function() {
        let x = this.i*w; //x-coordinat, its column location
        let y = this.j*w; //y-coordinat, its row location? or just the location of this specific cell (?)
        stroke(255); //what is stroke() = det er en streg

        if (this.walls[0]) { //maybe a switch-statement
            line(x, y, x+w, y); //horizontal line - top
        }
        if (this.walls[1]) {
            line(x+w, y, x+w, y+w); // vertical linje - right side
        }
        if(this.walls[2]) {
            line(x+w, y+w, x, y+w); // horizontal line - bottom
        }
        if (this.walls[3]) {
            line(x, y+w, x, y); // vertical line - left side
        }
        
        if(this.visited) {
            noStroke();
            fill(255,0, 225, 100);
            rect(x,y,w,w);
        }
    }
}

function removeWalls(a,b) {

    let x = a.i - b.i;
    if(x === 1 ) {
        a.walls[3] = false; //left wall removed, so a's left wall, and b's right wall
        b.walls[1] = false;
    } else if (x === -1) {
        a.walls[1] = false; // so b's left wall, and a's right wall
        b.walls[3] = false;
    }

    let y = a.j - b.j;
    if(y === 1 ) {
        a.walls[0] = false; //a's top removed, b's bottoms removed
        b.walls[2] = false;
    } else if (y == -1) {
        a.walls[2] = false; //b's top removed, a's bottom removed
        b.walls[0] = false;
    }
}